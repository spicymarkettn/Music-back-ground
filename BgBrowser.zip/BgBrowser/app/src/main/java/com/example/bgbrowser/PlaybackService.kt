package com.example.bgbrowser

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.webkit.WebView
import androidx.core.app.NotificationCompat

/** Partage le WebView avec le service pour piloter la vidéo depuis la notification. */
object Player {
    var web: WebView? = null
    private fun js(body: String) {
        web?.evaluateJavascript(
            "(function(){var v=document.querySelector('video')||document.querySelector('audio');if(!v)return;$body})();", null
        )
    }
    fun play() = js("v.play()")
    fun pause() = js("v.pause()")
    fun toggle() = js("v.paused?v.play():v.pause()")
    fun seek(sec: Int) = js("v.currentTime=Math.max(0,v.currentTime+($sec))")
}

/** Service de premier plan : garde le processus vivant + boutons dans la notification. */
class PlaybackService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null

    private fun action(act: String, label: String, icon: Int, code: Int) =
        NotificationCompat.Action(
            icon, label,
            PendingIntent.getService(
                this, code, Intent(this, PlaybackService::class.java).setAction(act),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("bg_play", "Lecture en arrière-plan", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(this, "bg_play")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Lecture en cours")
            .setContentText("Touchez pour revenir au navigateur")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action("REW", "-10s", android.R.drawable.ic_media_rew, 1))
            .addAction(action("PAUSE", "Pause", android.R.drawable.ic_media_pause, 2))
            .addAction(action("PLAY", "Lecture", android.R.drawable.ic_media_play, 3))
            .addAction(action("FWD", "+10s", android.R.drawable.ic_media_ff, 4))
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, notif)

        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bgbrowser:play").apply { acquire(4 * 60 * 60 * 1000L) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "PLAY" -> Player.play()
            "PAUSE" -> Player.pause()
            "REW" -> Player.seek(-10)
            "FWD" -> Player.seek(10)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wakeLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
