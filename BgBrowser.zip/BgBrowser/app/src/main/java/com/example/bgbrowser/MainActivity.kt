package com.example.bgbrowser

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var urlBar: EditText

    // Makes pages believe they are always visible, so players don't auto-pause.
    private val keepAliveJs = """
        (function(){
          try {
            Object.defineProperty(document,'hidden',{get:function(){return false}});
            Object.defineProperty(document,'visibilityState',{get:function(){return 'visible'}});
            document.addEventListener('visibilitychange',function(e){e.stopImmediatePropagation()},true);
            window.addEventListener('blur',function(e){e.stopImmediatePropagation()},true);
          } catch(e){}
        })();
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        urlBar = EditText(this).apply {
            hint = "Adresse ou recherche"
            setSingleLine()
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> load(text.toString()); true }
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(v: WebView, url: String, f: Bitmap?) {
                    urlBar.setText(url); v.evaluateJavascript(keepAliveJs, null)
                }
                override fun onPageFinished(v: WebView, url: String) {
                    v.evaluateJavascript(keepAliveJs, null)
                }
            }
        }
        Player.web = web
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { onClick() }
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = { LinearLayout.LayoutParams(0, -2, 1f) }
            addView(btn("⏪ 10s") { Player.seek(-10) }, lp())
            addView(btn("⏯") { Player.toggle() }, lp())
            addView(btn("10s ⏩") { Player.seek(10) }, lp())
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(urlBar, LinearLayout.LayoutParams(-1, -2))
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(controls, LinearLayout.LayoutParams(-1, -2))
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
        load(savedInstanceState?.getString("url") ?: "https://www.youtube.com")
    }

    private fun load(input: String) {
        val s = input.trim()
        web.loadUrl(
            when {
                s.startsWith("http://") || s.startsWith("https://") -> s
                s.contains(".") && !s.contains(" ") -> "https://$s"
                else -> "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(s, "UTF-8")
            }
        )
    }

    // NOTE: we deliberately never call web.onPause() so media keeps playing.
    override fun onStop() {
        super.onStop()
        ContextCompat.startForegroundService(this, Intent(this, PlaybackService::class.java))
        web.evaluateJavascript(keepAliveJs, null)
    }

    override fun onStart() {
        super.onStart()
        stopService(Intent(this, PlaybackService::class.java))
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out); out.putString("url", web.url)
    }

    override fun onDestroy() { Player.web = null; web.destroy(); super.onDestroy() }
}
